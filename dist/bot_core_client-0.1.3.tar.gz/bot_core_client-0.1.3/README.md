# Bot Core

这是一个基于 NapCat_api // onebotV11 的 QQ 机器人核心包。

## 功能特性

- **反向WebSocket 连接**: 支持与 NapCat 建立 反向WebSocket 连接。
- **插件系统**: 支持动态加载和热重载插件。
- **API 封装**: 提供了完整的 NapCat API 封装。
- **日志系统**: 提供了带有颜色的日志输出。
- **动态配置**: 支持通过代码动态配置 URL 和插件目录。
- **参考文档**: https://napcat.apifox.cn/
## 感谢
感谢 gemini chatGPT 通义 
## 目录结构

```
bot_core/
├── api/            # API 封装
├── bot.py          # 机器人核心类
├── main.py         # 示例入口文件
├── plugin_manager.py # 插件管理器
├── logs.py         # 日志模块
└── __init__.py
```

## 初始化

```python
import asyncio
from bot_core import Bot

async def main():
    # 初始化机器人，指定 WebSocket URL 和插件目录 TOKEN可以为空
    bot = Bot(url=URL, token=TOKEN, plugin_dir="plugins")
    # 启动机器人
    await bot.run()

if __name__ == '__main__':
    asyncio.run(main())
```

## 插件开发

在 `plugins` 目录（或你指定的目录）下创建 `.py` 文件，定义异步函数即可作为插件加载。

```python
async def my_plugin(msg:Message, client: BotClient):
    # 处理消息逻辑
    pass
```


## 消息链

### 构造消息链

通过导入类

```python
from api.client import Message
```

~~~python
await client.send_msg()
~~~

#### 发送前缀：

.all(msg)，传入包装后的消息对象，自动识别是否是群或者私聊

.group(group_id||msg)，传入群号或消息对象，发送群消息

.private(user_id||msg)，传入用户id或消息对象，发送私聊消息

#### 其中消息链为：

.text(string)，添加文本消息

.at(int)，传入被at的qq号（仅群聊）

.image(str||url)，传入file://链接以及url

.face(int)，传入表情face_id

.reply(int)，传入回复的msg_id

.music(str,srt)，音乐卡片，第一个参数传入163或qq，第二个参数传入音乐id

**以下方未经测试**

.voice()，添加语音

.video()，添加视频

.json_msg()，json消息

.custom_music()，自定义音乐卡片

.dice()，添加骰子

.rps()，猜拳

#### 发送消息缀：

.send()，构造后的结尾缀，发送消息

#### 造消息实例

```python
await client.send_msg().all(msg).reply(msg.message_id).at(msg.user_id).text("你好").image("file:///").send()
```

其含义为，回复消息，群私聊都可以，at用户，发送文字你好，并附带图片

### 构造转发消息链
通过导入类

```python
from api.client import Message
```

~~~python
await client.send_msg()
~~~
#### 发送前缀

.all(msg)，传入包装后的消息对象，自动识别是否是群或者私聊

.group(group_id||msg)，传入群号或消息对象，发送群消息

.private(user_id||msg)，传入用户id或消息对象，发送私聊消息

#### 消息链为

.forward_node(user_id,nickname,content)

user_id:转发内容中构造消息的qq号码

nickname:转发内容中构造消息的qq昵称

content:转发内容中构造消息的消息链，传入string||消息链

#### 转发文字消息构造

```python
await (client
       .send_msg()
       .group(group_id)  # 或 .private(user_id) 用于私聊 或 .all(msg) 自动识别
       .forward_node(user_id, nickname, content)
       .forward_node(user_id, nickname, content)
       .send_forward())
```

发送转发消息，其内容为转发消息内两个消息对象

#### 转发消息链

```python
.forward_node(123456789, "用户A", [
    {"type": "text", "data": {"text": "这是"}},
    {"type": "face", "data": {"id": 14}},
    {"type": "text", "data": {"text": "包含表情的消息"}}
])
```
支持的消息类型包括：
- `text`: 文本消息
- `face`: 表情消息
- `image`: 图片消息
- `at`: @消息
- `reply`: 回复消息
- `record`: 语音消息
- `video`: 视频消息
- `music`: 音乐卡片消息
- `json`: JSON消息
- `dice`: 骰子消息
- `rps`: 猜拳消息
- `poke`: 戳一戳消息
- `markdown`: Markdown消息

#### 发送转发消息

使用 `.send_forward()` 方法发送构造好的转发消息：

```python
.send_forward()
```
####  使用示例

##### 简单文本转发

``` python
await (client
       .send_msg()
       .group(123456789)
       .forward_node(10001, "用户A", "这是用户A的消息")
       .forward_node(10002, "用户B", "这是用户B的消息")
       .send_forward())
```

##### 复杂消息链转发

``` python
await (client
       .send_msg()
       .group(123456789)
       .forward_node(10001, "用户A", [
           {"type": "text", "data": {"text": "这是"}},
           {"type": "face", "data": {"id": 14}},
           {"type": "text", "data": {"text": "用户A的消息"}}
       ])
       .forward_node(10002, "用户B", [
           {"type": "text", "data": {"text": "用户B的纯文本消息"}}
       ])
       .send_forward())
```


### 注

注：其原封装api都能继续使用

使用需导入

```python
from api.BotClient import BotClient
```


#### 发送群聊消息

| API名称 | 使用方法 |
|---------|----------|
| send_group_msg | `group_id: int, message: str` - 发送群文本消息 |
| send_group_at | `group_id: int, user_id: int, message: str` - 发送群艾特消息 |
| send_group_image | `group_id: int, file: str, url: Optional[str]` - 发送群图片 |
| send_group_face | `group_id: int, face_id: int` - 发送群系统表情 |
| send_group_json | `group_id: int, json_data: Dict[str, Any]` - 发送群JSON消息 |
| send_group_voice | `group_id: int, file: str, url: Optional[str]` - 发送群语音 |
| send_group_video | `group_id: int, file: str, url: Optional[str]` - 发送群视频 |
| send_group_reply | `group_id: int, message_id: int, message: str` - 发送群回复消息 |
| send_group_music_card | `group_id: int, music_type: str, id: str` - 发送群聊音乐卡片 |
| send_group_custom_music_card | `group_id: int, url: str, audio: str, title: str, singer: str, image: Optional[str]` - 发送群聊自定义音乐卡片 |
| send_group_dice | `group_id: int` - 发送群聊超级表情-骰子 |
| send_group_rps | `group_id: int` - 发送群聊超级表情-猜拳 |
| send_group_forward_msg | `group_id: int, messages: List[Dict], source: str, news, prompt: str, summary: str` - 发送群合并转发消息 |
| send_group_file | `group_id: int, file: str, name: str` - 发送群文件 |
| forward_msg_to_group | `group_id: int, message_id: int` - 消息转发到群 |
| send_group_poke | `group_id: int, user_id: int` - 发送群聊戳一戳 |
| send_group_ai_voice | `group_id: int, text: str, voice_id: Optional[int]` - 发送群AI语音 |

#### 发送私聊消息

| API名称 | 使用方法 |
|---------|----------|
| send_private_msg | `user_id: int, message: str` - 发送私聊文本消息 |
| send_private_image | `user_id: int, file: str, url: Optional[str]` - 发送私聊图片 |
| send_private_face | `user_id: int, face_id: int` - 发送私聊系统表情 |
| send_private_json | `user_id: int, json_data: Dict[str, Any]` - 发送私聊JSON消息 |
| send_private_voice | `user_id: int, file: str, url: Optional[str]` - 发送私聊语音 |
| send_private_video | `user_id: int, file: str, url: Optional[str]` - 发送私聊视频 |
| send_private_reply | `user_id: int, message_id: int, message: str` - 发送私聊回复消息 |
| send_private_music_card | `user_id: int, music_type: str, id: str` - 发送私聊音乐卡片 |
| send_private_custom_music_card | `user_id: int, url: str, audio: str, title: str, singer: str, image: Optional[str]` - 发送私聊自定义音乐卡片 |
| send_private_dice | `user_id: int` - 发送私聊超级表情-骰子 |
| send_private_rps | `user_id: int` - 发送私聊超级表情-猜拳 |
| send_private_forward_msg | `user_id: int, messages: List[Dict]` - 发送私聊合并转发消息 |
| forward_msg_to_private | `user_id: int, message_id: int` - 消息转发到私聊 |
| send_private_file | `user_id: int, file: str, name: str` - 发送私聊文件 |
| send_private_poke | `user_id: int` - 发送私聊戳一戳 |

#### 其他消息操作

| API名称 | 使用方法 |
|---------|----------|
| send_poke | `user_id: int, group_id: Optional[int]` - 发送戳一戳 |
| delete_msg | `message_id: int` - 撤回消息 |
| get_group_history_msg | `group_id: int, message_seq: Optional[int]` - 获取群历史消息 |
| get_msg | `message_id: int` - 获取消息详情 |
| get_forward_msg | `message_id: int` - 获取合并转发消息 |
| set_essence_msg | `message_id: int` - 贴表情（设置精华消息） |
| get_friend_history_msg | `user_id: int, message_seq: Optional[int]` - 获取好友历史消息 |
| get_essence_msg_list | `group_id: int` - 获取贴表情详情（获取精华消息列表） |
| send_forward_msg | `messages: List[Dict]` - 发送合并转发消息 |
| get_record | `file: str, out_format: str` - 获取语音消息详情 |
| get_image | `file: str` - 获取图片消息详情 |

#### 群管理相关

| API名称 | 使用方法 |
|---------|----------|
| set_group_kick | `group_id: int, user_id: int, reject_add_request: bool` - 群组踢人 |
| set_group_ban | `group_id: int, user_id: int, duration: int` - 群组单人禁言 |
| set_group_whole_ban | `group_id: int, enable: bool` - 群组全员禁言 |
| set_group_admin | `group_id: int, user_id: int, enable: bool` - 群组设置管理员 |
| set_group_card | `group_id: int, user_id: int, card: str` - 设置群名片（群备注） |
| set_group_name | `group_id: int, group_name: str` - 设置群名 |
| set_group_leave | `group_id: int, is_dismiss: bool` - 退出群组 |
| set_group_special_title | `group_id: int, user_id: int, special_title: str, duration: int` - 设置群组专属头衔 |

#### 信息查询相关

| API名称 | 使用方法 |
|---------|----------|
| get_login_info | 无参数 - 获取登录号信息 |
| get_friend_list | 无参数 - 获取好友列表 |
| get_group_info | `group_id: int, no_cache: bool` - 获取群信息 |
| get_group_list | 无参数 - 获取群列表 |
| get_group_member_info | `group_id: int, user_id: int, no_cache: bool` - 获取群成员信息 |
| get_group_member_list | `group_id: int` - 获取群成员列表 |

#### 请求处理相关

| API名称 | 使用方法 |
|---------|----------|
| set_friend_add_request | `flag: str, approve: bool, remark: str` - 处理加好友请求 |
| set_group_add_request | `flag: str, sub_type: str, approve: bool, reason: str` - 处理加群请求／邀请 |

#### 系统操作相关

| API名称 | 使用方法 |
|---------|----------|
| get_version_info | 无参数 - 获取版本信息 |
| get_status | 无参数 - 获取运行状态 |
| clean_cache | 无参数 - 清理缓存 |

示例：构造转发消息使用方法

```python
messages = [
            {
                "type": "node",
                "data": {
                    "user_id": "1549184870",
                    "nickname": "qwq",
                    "content": [
                        {
                            "type": "text",
                            "data": {
                                "text": message
                            }
                        }
                    ]
                }
            }
        ]
await client.send_group_forward_msg(group_id,messages,"房间数据","点击查看","房间数据")
```



### 消息对象

#### 如传入类型为msg: Message

其中方法为

.raw()，获取原始消息内容

.user_id()，获取用户ID

.message_id()，获取消息ID

.ragroup_id()，获取群ID（仅群聊消息）

.message_type()，获取消息类型（group/private）

.js()，获取原始字典对象

.dict()，获取原始字典对象（兼容旧方法）

.get()，获取消息字段



#### 如传入类型为msg: dict

则为原始字典

#### 使用方法

```python
msg.raw == "你好":
```
### 插件实例

```python
async def hello_reply(msg: Message, client: BotClient):
    """当收到'你好'时回复这条消息并@发送者加你好"""
    if msg.raw == "你好":
        await client.send_msg().all(msg).reply(msg.message_id).at(msg.user_id).text("你好").image("file:///C:/Users/LENOVO/Desktop/QQ_bot/plugins/src/1.png").send()
```
```python
async def forward_test_all(msg:dict, client: BotClient):
    message_type = msg.get("message_type")
    raw_message = msg.get("raw_message", "")
    
    if raw_message == "转发测试all"
        # 使用all方法自动识别消息类型
        await (client
               .send_msg()
               .all(msg)  # 自动根据msg识别是群聊还是私聊
               .forward_node(123456789, "用户A", "这是用户A的消息")
               .forward_node(987654321, "用户B", "这是用户B的消息")
               .send_forward())
```

